const $ = id => document.getElementById(id);
const auth = $("auth"), dashboard = $("dashboard");
let mode = "login";

function message(text, good = false) {
  $("message").textContent = text;
  $("message").style.color = good ? "#00ff88" : "#ff7777";
}
function setMode(next) {
  mode = next;
  $("registerFields").hidden = next !== "register";
  $("loginFields").hidden = next !== "login";
  message("");
}
$("showRegister").addEventListener("click", () => setMode("register"));
$("showLogin").addEventListener("click", () => setMode("login"));

async function post(url, data) {
  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "حدث خطأ.");
  return result;
}
async function enter(user) {
  auth.style.display = "none";
  dashboard.style.display = "block";
  $("welcome").textContent = user.username;
  $("roleText").textContent = user.role === "admin" ? "حساب مشرف" : "حساب مستخدم";
  if (user.role === "admin") {
    $("adminPanel").hidden = false;
    await loadUsers();
  }
}
async function loadUsers() {
  const res = await fetch("/api/admin/users");
  if (!res.ok) return;
  const data = await res.json();
  const table = document.createElement("table");
  const head = document.createElement("tr");
  ["اسم المستخدم", "الصلاحية", "تاريخ التسجيل"].forEach(label => {
    const th = document.createElement("th"); th.textContent = label; head.appendChild(th);
  });
  table.appendChild(head);
  data.users.forEach(user => {
    const row = document.createElement("tr");
    [user.username, user.role === "admin" ? "مشرف" : "مستخدم", user.created_at].forEach(value => {
      const td = document.createElement("td"); td.textContent = value; row.appendChild(td);
    });
    table.appendChild(row);
  });
  $("users").replaceChildren(table);
}
$("registerBtn").addEventListener("click", async () => {
  try {
    const result = await post("/api/register", {
      username: $("newUser").value,
      password: $("newPass").value,
      consent: $("consent").checked
    });
    await enter(result.user);
  } catch (e) { message(e.message); }
});
$("loginBtn").addEventListener("click", async () => {
  try {
    const result = await post("/api/login", {
      username: $("username").value,
      password: $("password").value
    });
    await enter(result.user);
  } catch (e) { message(e.message); }
});
$("logoutBtn").addEventListener("click", async () => {
  await post("/api/logout", {});
  dashboard.style.display = "none";
  auth.style.display = "block";
  $("adminPanel").hidden = true;
  setMode("login");
});
(async () => {
  const res = await fetch("/api/me");
  const data = await res.json();
  if (data.user) await enter(data.user);
})();
